lorem-framework
===============

a tool for beginners

Adding a page:

1. Create a file called test_page.php and save it in the pages folder.
2. To view the page, use the URL localhost/mysite/?page=test_page