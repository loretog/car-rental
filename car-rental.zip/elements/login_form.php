<form method="post">
		<input type="hidden" name="action" value="validate_user">
		<label>Username</label>
		<input type="text" name="username"><br>
		<label>Password</label>
		<input type="password" name="password"><br>
		<input type="submit" name="" value="Login">
</form>